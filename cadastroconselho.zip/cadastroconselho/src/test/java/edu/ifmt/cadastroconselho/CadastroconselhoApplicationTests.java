package edu.ifmt.cadastroconselho;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadastroconselhoApplicationTests {

	@Test
	void contextLoads() {
	}

}
